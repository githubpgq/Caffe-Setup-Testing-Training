cat python/requirements.txt | xargs -L 1 sudo pip install
